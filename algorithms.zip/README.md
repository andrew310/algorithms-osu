# Project 1: MSS
Andrew, Myles, Robert

HOW TO USE:

Simply place maxSubArray.py in the same folder as MSS_Problems.txt. Type in python maxSubArray.py and run it; it will read in each line of the text file
and run each array through each of the four algorithms. A separate text file will be created called MSS_Results.txt. Open that up once the file is finished running,
and the results will be there.